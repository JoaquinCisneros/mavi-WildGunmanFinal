#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include "Enemigo.h"

using namespace sf;

class Aliado : public Enemigo {

private:
	Texture aliadoText;
	Sprite aliadoSprite;
	bool vivo;
public:
	Aliado();
	bool estaVivo();
	void dibujar(RenderWindow *app);
	void posicionar();
	void revivir();
	void derrotar();
	void setPosition(int x, int y);
	Vector2f getPosition();
	bool colisiona(float x, float y);
};
