#include "PlayerCrosshair.h"
#include <iostream>

using namespace sf;

PlayerCrosshair::PlayerCrosshair() {
	crossTex.loadFromFile("Resources/crosshair.png");
	crossSprite.setTexture(crossTex);
	crossSprite.setScale(0.5, 0.5);

}
void PlayerCrosshair::dibujar(RenderWindow *app) {

	app->draw(crossSprite);
	// Dibuja el crosshair
}
void PlayerCrosshair::posicionar(float x, float y) {

	crossSprite.setPosition(x, y);
	// Actualiza la posicion del sprite con el movimiento del mouse

}
Vector2f PlayerCrosshair::getPos() {

	return crossSprite.getPosition();

};


