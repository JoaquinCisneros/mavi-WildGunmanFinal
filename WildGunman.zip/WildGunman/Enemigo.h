#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
using namespace sf;

class Enemigo {

private:
	Texture enemyText;
	Sprite enemySprite;
	bool vivo;

public:
	Enemigo();
	void dibujar(RenderWindow *app);
	bool estaVivo();
	bool colisiona(float x, float y);
	void derrotar();
	void posicionar();
	void revivir();
	void setPosition(int x, int y);
	Vector2f getPosition();
};
