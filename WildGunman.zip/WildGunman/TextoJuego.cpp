#include "TextoJuego.h"
#include <iostream>

using namespace sf;

TextoJuego::TextoJuego() {

	fuente.loadFromFile("Resources/FuenteRegular.ttf");
	texto.setFont(fuente);
	texto.setCharacterSize(30);
	texto.setFillColor(Color::White);
	
	puntuacion.setFont(fuente);
	puntuacion.setCharacterSize(20);
	puntuacion.setFillColor(Color::Red);

	puntos = 0;

}

void TextoJuego::setPuntuacion(int x) {

	if (x < 0) {
		puntos = 0;
	}
	else {
		puntos = x;
	}

}

void TextoJuego::dibujar(RenderWindow *app) {

	texto.setString("GAME OVER");
	texto.setPosition(300, 300);

	puntuacion.setString("Puntuacion: " + std::to_string(puntos) );
	puntuacion.setPosition(300, 500);

	app->draw(texto);
	app->draw(puntuacion);

}