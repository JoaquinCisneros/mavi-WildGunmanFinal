#pragma once
#include <SFML/Graphics.hpp>
#include "PlayerCrosshair.h"
#include "Enemigo.h"
#include "Aliado.h"
#include "TextoJuego.h"
using namespace sf;

class Juego {
public:
    Juego();
    ~Juego();
    void loop();
    void procesarEventos();
    void actualizar();
    void dibujar();
    void disparar();
    void generarSpriteAleatorio();

private:
    RenderWindow *app;
    PlayerCrosshair *myCrosshair;
    Enemigo* enemigos;
    Aliado*aliados;
    TextoJuego gameOver;
    int enemigosAbatidos;
    int aliadosAbatidos;
    int vidas;
    int score;
    float tiempoTranscurrido;
    float tiempoDeVida;
    Clock clock;
    //fondo
    Texture fondoText;
    Sprite fondo;
};
