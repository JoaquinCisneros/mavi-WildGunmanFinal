#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "juego.h"
#include "Enemigo.h"
#include "TextoJuego.h"
#include "PlayerCrosshair.h"

using namespace sf;

Juego::Juego() {
    // Constructor
    app = new RenderWindow(sf::VideoMode(800, 600, 32), "WildGunman");
    app->setMouseCursorVisible(false);
    myCrosshair = new PlayerCrosshair();
    enemigos = new Enemigo();
    aliados = new Aliado();
    enemigosAbatidos = 0;
    aliadosAbatidos = 0;
    vidas = 3;
    tiempoDeVida = 3.0;
    tiempoTranscurrido = 0.0;
    clock.restart();
    app->setFramerateLimit(60);
    score = 0;

    //Fondo

    fondoText.loadFromFile("Resources/Fondo.png");
    fondo.setTexture(fondoText);
 
}

void Juego::generarSpriteAleatorio() {

    // Generar un n�mero aleatorio entre 0 y 2
    int randomNumber = std::rand() % 3;

    // Cambiar la posici�n del sprite seg�n el n�mero aleatorio
    if (randomNumber == 0) {
        // 2/3 de posibilidades de que aparezca enemigo
        enemigos->revivir();
        enemigos->posicionar();
        aliados->derrotar();
    }
    else {
        // 1/3 de posibilidades de que aparezca aliado
        aliados->revivir();
        aliados->posicionar();
        enemigos->derrotar();
    }

    // Reiniciar el reloj
    clock.restart();

}

void Juego::procesarEventos() {
    Event evt;
    while (app->pollEvent(evt)) {
        switch (evt.type) {
        case Event::Closed:
            app->close();
            break;
        case Event::MouseMoved:
            //Actualiza la posicion del crosshair con el movimiento del mouse
            myCrosshair->posicionar(evt.mouseMove.x, evt.mouseMove.y);
            break;
            //input con buffers
        case Event::MouseButtonPressed:
            if (evt.mouseButton.button == Mouse::Button::Left) {
                disparar();
            }
            break;
        }
    }
}

void Juego::disparar() {
    Vector2f crossPos = myCrosshair->getPos();
    //Chequear colisiones
    if (enemigos->estaVivo()) {
        if (enemigos->colisiona(crossPos.x, crossPos.y)) {
            enemigosAbatidos++;
            enemigos->derrotar();
            generarSpriteAleatorio();
        }
    }
    if (aliados->estaVivo()) {
        if (aliados->colisiona(crossPos.x, crossPos.y)) {
            vidas--;
            aliadosAbatidos++;
            aliados->derrotar();
            generarSpriteAleatorio();
        }
    }

}


void Juego::actualizar() {
    // Cada 3s si no se clickea en el enemigo se pierde una vida
    // O genera otro sprite si es un aliado
    std::cout <<"vidas: " <<vidas << "  enemigos abatidos: " << enemigosAbatidos << " score: " <<score << std::endl;
    tiempoTranscurrido = clock.getElapsedTime().asSeconds();
    
    if (vidas > 0) {
        if (tiempoTranscurrido > tiempoDeVida) {

            if (enemigos->estaVivo()) {
                vidas--;
                generarSpriteAleatorio();
            }
            else {

                if (aliados->estaVivo()) {

                    generarSpriteAleatorio();

                }

            }
        }
    }
    score = enemigosAbatidos - (aliadosAbatidos * 3);
    gameOver.setPuntuacion(score);
}

void Juego::dibujar() {
    app->clear();
    app->draw(fondo);
    aliados->dibujar(app);
    enemigos->dibujar(app);
    myCrosshair->dibujar(app);
    if (vidas < 1) {
        enemigos->setPosition(-500, -500);
        aliados->setPosition(-500, -500);
        gameOver.dibujar(app);
    }
    app->display();
}

void Juego::loop() {
    while (app->isOpen()) {
        procesarEventos();
        dibujar();
        actualizar();
    }
}


Juego::~Juego() {
    delete enemigos;
    delete aliados;
    delete myCrosshair;
    delete app;
}



