#include "Enemigo.h"
#include <ctime>
#include <cstdlib>

using namespace sf;

Enemigo::Enemigo() {
	enemyText.loadFromFile("Resources/et.png");
	enemySprite.setTexture(enemyText);
	enemySprite.setScale(0.07, 0.07);
	enemySprite.setPosition(100, 100);
	vivo = true;
}

void Enemigo::dibujar(RenderWindow *app) {

	app->draw(enemySprite);

}

bool Enemigo::estaVivo() {

	if (enemySprite.getPosition().x != -200) {
	
		vivo = 1;
	
	}

	return vivo;

}

bool Enemigo::colisiona(float x, float y) {
	// Chequea si hay colisiones con el sprite
	FloatRect bounds = enemySprite.getGlobalBounds();
	return bounds.contains(x, y);

}

void Enemigo::derrotar() {

	vivo = false;
	enemySprite.setPosition(-200, -200);

}

void Enemigo::revivir() {

	vivo = true;

}

void Enemigo::posicionar() {
	//regenerar enemigos en las posiciones predispuestas
	int posicion = 0;
		posicion = 1 + rand() % 6;
		switch (posicion) {
		case 1:
			enemySprite.setPosition(100, 100);
			break;
		case 2:
			enemySprite.setPosition(350, 100);
			break;
		case 3:
			enemySprite.setPosition(600, 100);
			break;
		case 4:
			enemySprite.setPosition(100, 400);
			break;
		case 5:
			enemySprite.setPosition(350, 400);
			break;
		case 6:
			enemySprite.setPosition(600, 400);
			break;
		}

}

Vector2f Enemigo::getPosition() {

	return enemySprite.getPosition();

}

void Enemigo::setPosition(int x, int y) {

	enemySprite.setPosition(x, y);

}
