#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include <string>


using namespace sf;

class TextoJuego {
private:
    Font fuente;
    Text texto;
    Text puntuacion;
    Text vidas;

    int puntos;

public:
    TextoJuego();
    void setPuntuacion(int x);
    void dibujar(RenderWindow *app);
};