#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

class PlayerCrosshair {

private:
	Texture crossTex;
	Sprite crossSprite;

public:
	PlayerCrosshair();
	void dibujar(RenderWindow *app);
	void posicionar(float x, float y);
	Vector2f getPos();

};
