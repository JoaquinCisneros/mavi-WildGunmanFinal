#include "Aliado.h"
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>

using namespace sf;

Aliado::Aliado() {
	aliadoText.loadFromFile("Resources/Estrella.png");
	aliadoSprite.setTexture(aliadoText);
	aliadoSprite.setScale(0.2, 0.2);
	aliadoSprite.setRotation(0.2);
	aliadoSprite.setPosition(-200, -200);
	vivo = false;
}

void Aliado::dibujar(RenderWindow* app) {

	app->draw(aliadoSprite);

}

void Aliado::posicionar() {
	//regenerar aliados en las posiciones predispuestas
	int posicion = 0;
		posicion = 1 + rand() % 6;
		switch (posicion) {
		case 1:
			aliadoSprite.setPosition(100, 100);
			break;
		case 2:
			aliadoSprite.setPosition(350, 100);
			break;
		case 3:
			aliadoSprite.setPosition(600, 100);
			break;
		case 4:
			aliadoSprite.setPosition(100, 400);
			break;
		case 5:
			aliadoSprite.setPosition(350, 400);
			break;
		case 6:
			aliadoSprite.setPosition(600, 400);
			break;
		}

}

bool Aliado::estaVivo() {

	if (aliadoSprite.getPosition().x == -200) {
		vivo = 1;
	}
	return vivo;
}

bool Aliado::colisiona(float x, float y) {
	// Chequea si hay colisiones con el sprite
	FloatRect bounds = aliadoSprite.getGlobalBounds();
	return bounds.contains(x, y);

}

void Aliado::derrotar() {

	vivo = false;
	aliadoSprite.setPosition(-200, -200);

}

void Aliado::revivir() {

	vivo = true;

}

Vector2f Aliado::getPosition() {

	return aliadoSprite.getPosition();

}

void Aliado::setPosition(int x, int y) {

	aliadoSprite.setPosition(x, y);

}
