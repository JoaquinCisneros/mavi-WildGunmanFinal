#include <iostream>
#include "Juego.h"
#include "PlayerCrosshair.h"

using namespace std;

int main() {
	srand(static_cast<unsigned int>(std::time(nullptr)));

	Juego myJuego;
	myJuego.loop();

	return 0;
}